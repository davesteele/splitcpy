#!/usr/bin/python

from .version import __version__
from .splitcpy import *         # flake8: noqa

splitcpy.__version__ = __version__
