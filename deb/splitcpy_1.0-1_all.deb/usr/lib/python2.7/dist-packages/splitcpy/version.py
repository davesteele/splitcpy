#!/usr/bin/python

__version__ = "1.0"


__VER_DL_MIN__ = "1.0"
__VER_DL_MAX__ = "1.99"
